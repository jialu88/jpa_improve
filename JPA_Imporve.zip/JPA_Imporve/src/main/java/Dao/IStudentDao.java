package Dao;

public interface IStudentDao {
    boolean Login(String name, String password);
}
