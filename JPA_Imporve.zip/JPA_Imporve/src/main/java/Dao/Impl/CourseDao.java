package Dao.Impl;

import Entity.Course;

public class CourseDao extends BaseDao<Course>{
}
